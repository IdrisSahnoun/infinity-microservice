from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

# Initialisation de la base de données
db = SQLAlchemy(app)

# Modèle simple pour tester la connexion
class TestModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))

@app.cli.command("init-db")
def init_db():
    """Initialise la base de données."""
    with app.app_context():
        db.create_all()
    print("Tables créées avec succès !")

@app.route('/')
def home():
    return "Connexion à la base de données réussie !"

if __name__ == '__main__':
    app.run(debug=True)